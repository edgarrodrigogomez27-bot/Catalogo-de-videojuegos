package com.example.catalogo

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

@Composable
fun PantallaAcerca() {
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFFF4511E)), contentAlignment = Alignment.Center) {
        Text("Aplicación realizada como parte de Actividad 8\n\nCatálogo de Videojuegos\n\nHecha por:\n• Edgar Rodrigo Guevara Gómez\n• Angel de Jesus Aguilar Ortega", color = Color.White)
    }
}

