package com.example.catalogo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.catalogo.data.CarritoRepository
import com.example.catalogo.data.entities.CarritoEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CarritoViewModel(private val repo: CarritoRepository) : ViewModel() {

    val items: StateFlow<List<CarritoEntity>> =
        repo.carrito.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    fun add(nombre: String, precio: Double) {
        viewModelScope.launch {
            repo.agregar(nombre, precio)
        }
    }

    fun remove(item: CarritoEntity) {
        viewModelScope.launch {
            repo.eliminar(item)
        }
    }

    fun clearCart(onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repo.limpiar()
            onDone()
        }
    }
}
