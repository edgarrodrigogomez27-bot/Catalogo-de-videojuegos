package com.example.catalogo.data.database

import androidx.room.*
import com.example.catalogo.data.entities.CarritoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CarritoDao {
    @Query("SELECT * FROM carrito")
    fun obtenerCarrito(): Flow<List<CarritoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun agregarProducto(producto: CarritoEntity)

    @Delete
    suspend fun eliminarProducto(producto: CarritoEntity)

    @Query("DELETE FROM carrito")
    suspend fun limpiarCarrito()
}
